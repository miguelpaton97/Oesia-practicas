package com.oesia.formacion.practica.remote;

public interface RemoteManager {

	void recive(String message);
}
