package com.oesia.formacion.practica.architecture.domain.managers.workorder;

public class WorkOrder {

	private final int WorkId;
	
	public WorkOrder (int WorkId) {
		this.WorkId = WorkId;
	}

	public int getWorkId() {
		return WorkId;
	}
}