package com.oesia.formacion.practica.context;

// Patrón Singleton (simple)
public class ContextFactory {

	private static Context INSTANCE = null;

	public static Context getContext() {
		if (INSTANCE == null) {
			INSTANCE = new Context();
		}
		return INSTANCE;
	}

}
