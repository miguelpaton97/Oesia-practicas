package com.oesia.formacion.practica.architecture.persistence.daos;

import java.util.List;

public interface Dao<E> {

	E findById(Integer id);

	List<E> findAll();
}
