package com.oesia.formacion.practica.architecture.communications;

public interface MessageManager {

	void recive(String message);

	void send(String message);

}
