package com.oesia.formacion.practica.architecture.communications.processors;

import com.oesia.formacion.practica.architecture.domain.model.Message;

public interface Processor {
	
	void process(Message message);

}
